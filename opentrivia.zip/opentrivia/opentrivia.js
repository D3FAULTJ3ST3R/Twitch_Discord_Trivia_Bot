/**
	Original Programmer: D3FAULTJ3ST3R
	Project: Trivia Bot

	ANY VARIABLES THAT NEED TO BE EDITED TO WORK WILL BE HAVE *EDIT ME* - SO SEARCH BY THAT TO FIND THEM

	Make sure you edit the files under // Local Authorization Files

	Make sure you also have a MYSQL server setup and ready. More info in the README about this.

	Also take a chance to read the README!
*/

// What Services Do You Want The Bot To Run On?
const TwitchRun = true; // If true, the bot will run on Twitch.
const DiscordRun = true; // If true, the bot will run on Discord.

// Required NPM Files
const tmi = require('tmi.js'); // Twitch JS Library - https://github.com/tmijs
const mysql = require('mysql'); // MYSQL JS Library - https://www.npmjs.com/package/mysql
const Discord = require('discord.js'); // Discord JS Library - https://discord.js.org/#/
const stringSimilarity = require('string-similarity'); // String Comparison Library - https://www.npmjs.com/package/string-similarity
const request = require('request'); // Request JS Library - https://www.npmjs.com/package/request -- DEPRECATED LIBRARY -- USED OUT OF LAZINESS

// Local Authorization Files & Variables - All files should be in the same folder as opentrivia.js
const mysqlAuth = require('./mysqlAuth.js');
const twitchAuth = require('./twitchAuth.js');
const discordAuth = require('./discordAuth.js');
const twitchClientID = require('./twitchClientID.js');

// MYSQL Variables To Edit
const mysqlUser = 'username'; 	// Username for MYSQL.															*EDIT ME*
const host = 'localhost';		// Host Address for MYSQL - default for local MYSQL or WAMP MYSQL is localhost. *EDIT ME*
const database = 'database';	// Database name for MYSQL.														*EDIT ME*

// Variables To Edit
const authorizedUsers = ['username'];				// Array of Twitch Users authorized to use the start command, use all lowercase. Include commas between strings. '1', '2', 'etc'.				*EDIT ME*
const twitchBotName = 'twitchBotName';				// The username of the Twitch Bot.																												*EDIT ME*
const channelsToWatch = ['channelName'];			// Array of channels for the bot to watch and listen to, can do multiple, use all lowercase. Include commas between strings. '1', '2', 'etc'.	*EDIT ME*
var channelsLive = [];								// Array of the live statuses for channelsToWatch that will update if set to twitchAutoMode
const discordBotChannel = 'discordChannelID'; 		// Enter the channel id in which you'd like the bot to keep responses locked down to.															*EDIT ME*
const twitchPrefix = 'chooseBotPrefix';				// Twitch - Choose what symbol you'd like to put in front of bot commands. EX: '!', '$', '#'.													*EDIT ME*
const discordPrefix = 'chooseBotPrefix';			// Discord - Choose what symbol you'd like to put in front of bot commands. EX: '!', '$', '#'.													*EDIT ME*
const answerSimilarityPercent = .8;					// Minimum percentage of similarity answer needs to be correct. Default: 80%.

// Bot Mode - * means default setting when downloaded.
var twitchAutoMode = true; 		// * If set to true, this bot will automatically begin to ask questions if the channel is live.
								// If set to false, you will have to use a command to start and stop the bot from using Twitch.													
const autoSyncMode = true;		// * If set to true, this will mean that when Twitch comes online, it will swap to synchronous mode.
								// If set to false, the bot will keep synchronousMode set to false.
var synchronousMode = false;	// Keep set to false, bot will automatically swap to true if autoSyncMode is true when Twitch comes online.
								// If set to true, this will mean that the bot uses the same questions in both Twitch and Discord.
								// * If set to false, the bot will rely on different table values to ensure that questions aren't shared.
const syncSharedMode = false;	// This field only matters if synchronousMode is set to true - BUT MUST STILL HAVE A VALUE OF ONE OR THE OTHER!
								// If set to true, this means that only one user between both Twitch and Discord may answer correctly.
								// * If set to false, this means that both Twitch and Discord may have their own seperate winner.
const consequenceMode = true;	// * If set to true, users may only answer once and will have money deducted for incorrect answers.
								// If set to false, users may answer more than once and will have no money deducted ever.

/*
	Quick Note On Timer Variables.

	When setting the time between questions, attempt to
	have it be set to a number where you can divide 60
	by the variable, and get an even number. This helps
	the bot determine when to start the timer and spit
	out questions.

	Although I also suggest having it be at least 5. Otherwise,
	chat logs and server chat may become very spammy.

	For instance: 1, 2, 3, 4, 5, 6, 10, 12, 15, 20.
*/
// General Timer Variables
const second = 1000;
const minute = second * 60;
const timerForLiveCheck = 10; 	// Time between checks if Twitch channels are live in seconds. Recommend setting to roughly 2 times the amount of channels at least.
var timezone = "EST";			// This is the timezone for the bot. Please set it to your timezone.																	*EDIT ME*

// Timer Variables - Synchronous Mode
const timeBetweenQuestions = 5; // Time between the bot asking questions in minutes. 60 or higher will not work.
const timeToAnswer = 60; 		// Time to enter answers during the question phase in seconds.
var nextQuestionTime = null; 	// This will be a variable holding the next questions time.
var intervalRunner = null; 		// Variable to be tied to the setInterval() for running the runQuestion function.
var answersUpRunner = null;		// Variable to be tied to the setTimeout() for ruunning the answersUp function.

// Timer Variables - Asynchronous Mode

// Twitch Timers
const timeBetweenQuestionsTwitch = 5; 	// Time between the bot asking questions in minutes. 60 or higher will not work.
const timeToAnswerTwitch = 60; 			// Time to enter answers during the question phase in seconds.
var nextQuestionTwitch = null; 			// This will be a variable holding the next questions time.
var intervalRunnerT = null; 			// Variable to be tied to the setInterval() for running the runQuestion function.
var answersUpRunnerT = null;			// Variable to be tied to the setTimeout() for ruunning the answersUp function.

// Discord Timers
const timeBetweenQuestionsDiscord = 5; 	// Time between the bot asking questions in minutes. 60 or higher will not work.
const timeToAnswerDiscord = 60; 		// Time to enter answers during the question phase in seconds.
var nextQuestionDiscord = null; 		// This will be a variable holding the next questions time.
var intervalRunnerD = null; 			// Variable to be tied to the setInterval() for running the runQuestion function.
var answersUpRunnerD = null;			// Variable to be tied to the setTimeout() for ruunning the answersUp function.

// Global Variables - Synchronous Mode
var questionid = null; 				// ID of the question in the MYSQL table.
var questionDate = null;			// Date of when the question was created.
var category = null;				// Category of the question.
var question = null;				// The question.
var answer = null;					// The answer to the question.
var value = null;					// Monetary value of question.
var answered = false;				// Check if the question has been answered - Single
var questiontime = false;			// Check if it is currently time to give answers.
var answeredTwitch = false;			// Check if the question has been answered - Twitch.
var answeredDiscord = false;		// Check if the question has been answered - Discord.
var questiontimeTwitch = false;		// Check if it is currently time to give answers - Twitch.
var questiontimeDiscord = false;	// Check if it is currently time to give answers - Discord.
var Sused = null;					// Amount of times this question has been used.

// Global Variables - Asynchronous Mode - Twitch
var Tquestionid = null; 		// ID of the question in the MYSQL table.
var TquestionDate = null;		// Date of when the question was created.
var Tcategory = null;			// Category of the question.
var Tquestion = null;			// The question.
var Tanswer = null;				// The answer to the question.
var Tvalue = null;				// Monetary value of question.
var Tanswered = false;			// Check if the question has been answered - Single
var Tquestiontime = false;		// Check if it is currently time to give answers.
var Tused = null;				// Amount of times this question has been used.

// Global Variables - Asynchronous Mode - Discord
var Dquestionid = null; 		// ID of the question in the MYSQL table.
var DquestionDate = null;		// Date of when the question was created.
var Dcategory = null;			// Category of the question.
var Dquestion = null;			// The question.
var Danswer = null;				// The answer to the question.
var Dvalue = null;				// Monetary value of question.
var Danswered = false;			// Check if the question has been answered - Single
var Dquestiontime = false;		// Check if it is currently time to give answers.
var Dused = null;				// Amount of times this question has been used.

// Global registries - Keep track of registered users
var discordRegistered = [];
var twitchRegistered = [];
var discordMoney = [];
var twitchMoney = [];
var discordAnswered = [];
var twitchAnswered = [];

// Global Clients - These are the clients for each of our services that we will use
var mysqlClient = null;
var twitchClient = null;
var discordClient = null;

// Log Into MYSQL, Twitch, And Discord
Login();

// If set to Twitch Auto Mode, check if all channels are live every 10 seconds - Shouldn't go below 5 seconds
if(twitchAutoMode && TwitchRun) {
  setInterval(channelsLiveRun, timerForLiveCheck * second);
} else {
  // Set all channels to "not live"
  for(var i = 0; i < channelsToWatch.length; i++) {
    channelsLive[i] = false; // Set channel to not live
  }
}

// If Twitch is a running service, fill an array with all the registered trivia players
if(TwitchRun) {
  fillReg('twitch');
}

// If Discord is a running service, fill an array with all the registered trivia players
if(DiscordRun) {
  fillReg('discord');
}

// Initialize our first questions - Timeout to attempt waiting til channelsLiveRun finds all channels and sees if they're online
setTimeout(initQuestions, 3000 * channelsToWatch.length + timerForLiveCheck * second);

// Function receives all messages from Twitch from any channel in the channelsToWatch array
function onMessageTwitch (target, context, msg, self) {
	// Ignore messages from the bot
	if (self) {
		return; 
	}

	// Create all variables based on the incoming message
	const message = msg.trim();                         						// Trims whitespace off the message
	const messageUser = context['username'];                 			 		// Grabs the user who sent the message.
	const twitchTarget = target;                        						// Grabs the channel target to send messages back.
	const twitchChannel = target.substring(1);                  				// Grabs the name of the Twitch channel.            
	const rewardid = context["custom-reward-id"];                 				// Grabs the reward id if there is one tied to the message.
	const channelIndex = channelsLive[channelsToWatch.indexOf(twitchChannel)];  // Grabs the index of the channelsLive array where this channel is.
	const checker = checkIfReg('twitch', messageUser);              			// Checks if the user is registered to our database.
	const alreadyAnswered = hasUserAnswered('twitch', messageUser); 			// Checks if the user has already answered.

	// Commands available when channel is live
	if(channelsLive[channelIndex]) {
	    // If command == !endTheShow and bot isn't set to auto mode
	    if(message.startsWith(twitchPrefix + "endTheShow") && !twitchAutoMode) {
	      // If command came from an authorized user
	      if(authorizedUsers.includes(messageUser)) {
	        // A variable to track if Live statuses change or sync status
	        var wereLive = channelsLive.includes(true);
	        var wasSync = synchronousMode;

	        // Set Channel to "Live"
	        channelsLive[channelIndex] = false;

	        // Check the sync / live status and if it should change our questions or mode
	        syncQuestionStatus(wereLive, wasSync);
	      }
	    }

	    // Custom Reward for registering - Be sure to set setRewardID up above
	    if (rewardid == setRewardID) {
			// If registered in the Twitch database, output an error message to Twitch chat, otherwise, register them as a new user
			if(checker) {
				twitchClient.say(twitchTarget, `Sorry @${messageUser}, you are already registered!`);
			} else {
				register('twitch', messageUser);
				twitchClient.say(twitchTarget, `Thank you @${messageUser} for registering for trivia!`);
			}
			return;
	    }

	    // Trivia command outputs information about the bot
	    if(message.startsWith(twitchPrefix + "trivia")) {
			twitchClient.say(twitchTarget, "Greetings! I'm a Trivia Bot created by D3FAULTJ3ST3R! To play, simply register by redeeming the Trivia Register Channel Point Reward! I play trivia in both Twitch and Discord! Check out my Twitch or my socials @D3FAULTJ3ST3R for more information!");
			return;
	    	// Money command outputs how much money the user using the command has
	    } else if(message.startsWith(twitchPrefix + "money")) {
	      	if(checker) {
		        var money = checkMoney('twitch', messageUser);
		        twitchClient.say(twitchTarget, `@${messageUser}, you have $${money}!`);
		        return;
	      	} else {
	        	twitchClient.say(twitchTarget, `Sorry @${messageUser}, you are not registered to play, please use the Register For Trivia Channel Point Reward to register!`);
	        	return;
	      	}
	    	// Timer command outputs next time a question will be posted
	    } else if(message.startsWith(twitchPrefix + "timer")) {
			if(synchronousMode) {
				twitchClient.say(twitchTarget, `Time Of Next Question: ${nextQuestionTime}`);
				return;
			} else {
				twitchClient.say(twitchTarget, `Time Of Next Question: ${nextQuestionTwitch}`);
				return;
			}
			// Answer command attempts to answer the question
	    } else if(message.startsWith(twitchPrefix + "answer")) {
	    	// Check the "checker" variable to see if the user is registered
	    	if(!checker) {
	        	twitchClient.say(twitchTarget, `Sorry @${messageUser}, you are not registered to play, please use the Register For Trivia Channel Point Reward to register!`);
	        	return;
	      	}

	      	// Check if the bot is running in synchronous mode
	      	if(synchronousMode) {
		        // Check if answer shared mode is set to true
		        if(syncSharedMode) {
		        	// Check if the question has been answered yet
		          	if(!answered && questiontime && !alreadyAnswered) {
		          		// Set user to answered
		            	userAnswered('twitch', messageUser);

		            	// If answer was correct
		            	if(checkAnswer(answer, message.replaceAll(twitchPrefix + 'answer', '').toLowerCase().trim())) {
		            		// Set question to answered and don't allow anymore answers
		              		answered = true;
		              		questiontime = false;

		              		// Tell the user they won and how much they won
		              		twitchClient.say(twitchTarget, `Excellent job @${messageUser}, you win ${value}!`);

		              		// Apply the winnings to the user's database entry
		              		payUser('twitch', messageUser, value);

		              		// Clearout the timeout function
		              		clearTimeout(answersUpRunner);

		              		// Run answersUp early
		              		answersUp('sync');
		            	} else {
		            		// Check if the bot is set to consequence mode
		              		if(consequenceMode) {
		              			// Deduct money from the user and warn them of the deduction
		                		deductUser('twitch', messageUser, value);
		                		twitchClient.say(twitchTarget, `Sorry @${messageUser}, that is incorrect! You have been deducted $${value}!`);
		              		} else {
		              			// Tell the user they're incorrect
		                		twitchClient.say(twitchTarget, `Sorry @${messageUser}, that is incorrect!`);
		              		}
		            	}
		          	} else {
		          		// Warn user now is not the time to answer
		            	twitchClient.say(twitchTarget, `Sorry @${messageUser}, it is not time to attempt answering questions!`);
		          	}
		        } else {
		        	// Check if a Twitch user has answered yet
		        	if(!answeredTwitch && questiontimeTwitch && !alreadyAnswered) {
		        		// Set user to answered
		            	userAnswered('twitch', messageUser);

		            	// If answer was correct
		            	if(checkAnswer(answer, message.replaceAll(twitchPrefix + 'answer', '').toLowerCase().trim())) {
		              		// Set question to answered and don't allow anymore answers
		              		answeredTwitch = true;
		              		questiontimeTwitch = false;

		              		// Tell the user they won and how much they won
		              		twitchClient.say(twitchTarget, `Excellent job @${messageUser}, you win ${value}!`);

		              		// Apply the winnings to the user's database entry
		              		payUser('twitch', messageUser, value);

		              		// Clearout the timeout function
		              		clearTimeout(answersUpRunnerT);

		              		// Run answersUp early
		              		answersUp('sync');
		            	} else {
		            		// Check if the bot is set to consequence mode
		              		if(consequenceMode) {
		              			// Deduct money from the user and warn them of the deduction
		                		deductUser('twitch', messageUser, value);
		                		twitchClient.say(twitchTarget, `Sorry @${messageUser}, that is incorrect! You have been deducted $${value}!`);
		              		} else {
		              			// Tell the user they're incorrect
		                		twitchClient.say(twitchTarget, `Sorry @${messageUser}, that is incorrect!`);
		              		}
		            	}
		          	} else {
		          		// Warn user now is not the time to answer
		            	twitchClient.say(twitchTarget, `Sorry @${messageUser}, it is not time to attempt answering questions!`);
		          	}
		        }
	      	} else {
	        	// Check if it's time to answer a question
	        	if(!Tquestiontime) {
	        		// Warn user now is not the time to answer
	          		twitchClient.say(twitchTarget, `Sorry @${messageUser}, it is not time to attempt answering questions!`);
	        	} else {
	        		// Check if the question has been answered on Twitch
	          		if(!Tanswered && !alreadyAnswered) {

	          			// Set user to answered
	            		userAnswered('twitch', messageUser);

	            		// If answer was correct
	            		if(checkAnswer(Tanswer, message.replaceAll(twitchPrefix + 'answer', '').toLowerCase().trim())) {
	            			// Set question to answered and don't allow anymore answers
	              			Tanswered = true;
	              			Tquestiontime = false;

	              			// Tell the user they won and how much they won
	              			twitchClient.say(twitchTarget, `Excellent job @${messageUser}, you win ${Tvalue}!`);

	              			// Apply the winnings to the user's database entry
	              			payUser('twitch', messageUser, Tvalue);

	              			// Clearout the timeout function
		              		clearTimeout(answersUpRunnerT);

		              		// Run answersUp early
		              		answersUp('async_twitch');
	            		} else {
	            			// Check if the bot is set to consequence mode
	              			if(consequenceMode) {
	              				// Deduct money from the user and warn them of the deduction
	                			deductUser('twitch', messageUser, Tvalue);
	                			twitchClient.say(twitchTarget, `Sorry @${messageUser}, that is incorrect! You have been deducted $${Tvalue}!`);
	              			} else {
	              				// Tell the user they're incorrect
	                			twitchClient.say(twitchTarget, `Sorry @${messageUser}, that is incorrect!`);
	              			}
	            		}
	          		}
	        	}
	      	} 	
	      	return;
	    } else {
	      	return;
	    }
    	// Commands available when channel is not live
  	} else {
	    // If command == !startTheShow and bot isn't set to auto mode
	    if(message.startsWith(twitchPrefix + "startTheShow") && !twitchAutoMode) {
			// If command came from an authorized user
			if(authorizedUsers.includes(messageUser)) {
				// A variable to track if Live statuses change or sync status
				var wereLive = channelsLive.includes(true);
				var wasSync = synchronousMode;

				// Set Channel to "Live"
				channelsLive[channelIndex] = true;

				// Sync Questions between Discord and Twitch
				syncQuestionStatus(wereLive, wasSync);
			}
	    }
  	}
}

// Function receives all messages from any Discord server the bot is a part of
function onMessageDiscord (msg) {
	// Ignore messages from the bot
	if (msg.author == discordClient.user) {
		return; 
	}

	// Create all variables based on the incoming message
	const message = msg.content;									// Grabs the message body.
	const messageUser = msg.author;									// Grabs the message user.
	const dUsername = msg.author.username;							// Grabs the username of the user.
	const channelID = msg.channel.id;								// Grabs the id of the channel.
	const checker = checkIfReg('discord', dUsername);				// Checks if the user is registered.
	const alreadyAnswered = hasUserAnswered('discord', dUsername);	// Checks if the user has already answered.

	// Checks if the id of the channel of the message origin is equal to the channel the bot operates in
	if(channelID == discordBotChannel) {
		// The register command registers new users
		if(message.startsWith(discordPrefix + "register")) {
			// Checks if user is already registered, if so, output an error that they're registered, otherwise, register the user
			if(checker) {
				msg.channel.send(`Sorry ${messageUser}, you are already registered!`);
			} else {
				register('discord', dUsername);
				msg.channel.send(`Thank you ${messageUser} for registering for trivia!`);
			}
			return;
			// The trivia command outputs bot info
		} else if(message.startsWith(discordPrefix + "trivia")) {
			msg.channel.send("Greetings! I'm a Trivia Bot created by D3FAULTJ3ST3R! To play, simply register by using the *register command to register for Trivia on Discord! I play trivia in both Twitch and Discord! Check out my Twitch or my socials @D3FAULTJ3ST3R for more information!");
			return;
			// The money command outputs how much money the user has
		} else if(message.startsWith(discordPrefix + "money")) {
			// Checks if the user is registered, if so, output money they have, otherwise, tell them to register to play
			if(checker) {
				var money = checkMoney('discord', dUsername);
				msg.channel.send(`${messageUser}, you have $${money}!`);
				return;
			} else {
				msg.channel.send(`Sorry ${messageUser}, you are not registered to play, please use the *register command to register for Trivia on Discord!`);
				return;
			}
			// The timer command outputs the next time the bot will output a question
		} else if(message.startsWith(discordPrefix + "timer")) {
			// Checks if bot is in synchronous mode, if so use sync timer, otherwise, use Discord timer
			if(synchronousMode) {
				msg.channel.send(`Time Of Next Question: ${nextQuestionTime}`);
				return;
			} else {
				msg.channel.send(`Time Of Next Question: ${nextQuestionDiscord}`);
				return;
			}
			// The answer command allows the user to attempt to answer the question
		} else if(message.startsWith(discordPrefix + "answer")) {
			// Check if the user is registered to play and answer, if not, tell user to register
			if(!checker) {
				msg.channel.send(`Sorry ${messageUser}, you are not registered to play, please use the *register command to register for Trivia on Discord!`);
				return;
			}

			// Check if the bot is running in sync mode
			if(synchronousMode) {
				// Check if the bot is running sync shared mode
				if(syncSharedMode) {
					// Check if the question is answered or if it's time to answer
					if(!answered && questiontime && !alreadyAnswered) {
						// Set the user to answered
						userAnswered('discord', dUsername);

						// If answer was correct
						if(checkAnswer(answer, message.replaceAll(discordPrefix + 'answer', '').toLowerCase().trim())) {
							// Set question to answered and don't allow anyone else to answer
							answered = true;
							questiontime = false;

							// Tell user they're correct and how much they won
							msg.channel.send(`Excellent job @${messageUser}, you win ${value}!`);

							// Apply payment to user's account
							payUser('discord', dUsername, value);

							// Clear the timeout for the answersUp function
							clearTimeout(answersUpRunner);

							// Run the answersUp function early
							answersUp('sync');
						} else {
							// Check if the bot is in consequence mode
							if(consequenceMode) {
								// Deduct money from users account and output how much they loss
								deductUser('discord', dUsername, value);
								msg.channel.send(`Sorry ${messageUser}, that is incorrect! You have been deducted $${value}!`);
							} else {
								// Warn user they were incorrect
								msg.channel.send(`Sorry ${messageUser}, that is incorrect!`);
							}
						}
					} else {
						// Warn user that now is not the time to attempt answering
						msg.channel.send(`Sorry ${messageUser}, it is not time to attempt answering questions!`);
					}
				} else {
					// Check if the question is answered or if it's time to answer
					if(!answeredDiscord && questiontimeDiscord && !alreadyAnswered) {
						// Set the user to answered
						userAnswered('discord', dUsername);

						// If answer was correct
						if(checkAnswer(answer, message.replaceAll(discordPrefix + 'answer', '').toLowerCase().trim())) {
							// Set question to answered and don't allow anyone else to answer
							answeredDiscord = true;
							questiontimeDiscord = false;

							// Tell user they're correct and how much they won
							msg.channel.send(`Excellent job ${messageUser}, you win ${value}!`);

							// Apply payment to user's account
							payUser('discord', dUsername, value);

							// Clear the timeout for the answersUp function
							clearTimeout(answersUpRunnerD);

							// Run the answersUp function early
							answersUp('sync');
						} else {
							// Check if the bot is in consequence mode
							if(consequenceMode) {
								// Deduct money from users account and output how much they loss
								deductUser('discord', dUsername, value);
								msg.channel.send(`Sorry ${messageUser}, that is incorrect! You have been deducted $${value}!`);
							} else {
								// Warn user they were incorrect
								msg.channel.send(`Sorry ${messageUser}, that is incorrect!`);
							}
						}
					} else {
						// Warn user that now is not the time to attempt answering
						msg.channel.send(`Sorry ${messageUser}, it is not time to attempt answering questions!`);
					}
				}
			} else {
				// Check if it's time to answer a question
				if(!Dquestiontime) {
						// Warn user that now is not the time to attempt answering
					msg.channel.send(`Sorry @${messageUser}, it is not time to attempt answering questions!`);
				} else {
					// Check if the question is answered or if it's time to answer
					if(!Danswered && !alreadyAnswered) {
						// Set the user to answered
						userAnswered('discord', dUsername);

						// If answer was correct
						if(checkAnswer(Danswer, message.replaceAll(discordPrefix + 'answer', '').toLowerCase().trim())) {
							// Set question to answered and don't allow anyone else to answer
							Danswered = true;
							Dquestiontime = false;

							// Tell user they're correct and how much they won
							msg.channel.send(`Excellent job @${messageUser}, you win ${Dvalue}!`);

							// Apply payment to user's account
							payUser('discord', dUsername, Dvalue);

							// Clear the timeout for the answersUp function
							clearTimeout(answersUpRunnerD);

							// Run the answersUp function early
							answersUp('async_discord');
						} else {
							// Check if the bot is in consequence mode
							if(consequenceMode) {
								// Deduct money from users account and output how much they loss
								deductUser('discord', dUsername, Dvalue);
								msg.channel.send(`Sorry ${messageUser}, that is incorrect! You have been deducted $${Dvalue}!`);
							} else {
								// Warn user they were incorrect
								msg.channel.send(`Sorry ${messageUser}, that is incorrect!`);
							}
						}
					}
				}
			}
			return;
		} else {
			return;
		}
	} 
}

// Fill the registry arrays
function fillReg(platform) {
  	// Query all players from the platform database and put them into the according array
  	mysqlClient.query(`SELECT * FROM jeopardy_players_${platform}`, function (err, result, fields) {
	    if(platform == 'twitch' && result.length != 0) {
	      	for(var y = 0; y < result.length; y++) {
	        	twitchRegistered[y] = result[y]['name'];
	        	twitchAnswered[y] = false;
	        	twitchMoney[y] = result[y]['money'];
	      	}
	    } else if(platform == 'discord' && result.length != 0) {
	      	for(var w = 0; w < result.length; w++) {
	        	discordRegistered[w] = result[w]['name'];
	        	discordAnswered[w] = false;
	        	discordMoney[w] = result[w]['money'];
	    	}
	    }
  	});
}

// Check if user has answered yet
function hasUserAnswered(platform, username) {
	// Check the array element with the index of the index in which the user's username is stored in the player array
	if(platform == 'twitch') {
		return twitchAnswered[twitchRegistered.indexOf(username)];
	} else if(platform == 'discord') {
		return discordAnswered[discordRegistered.indexOf(username)];
	}
}

// Set user to answered
function userAnswered(platform, username) {
	// Set the array element with the index of the index in which the user's username is stored in the player array
	if(platform == 'twitch') {
		twitchAnswered[twitchRegistered.indexOf(username)] = true;
	} else if(platform == 'discord') {
		discordAnswered[discordRegistered.indexOf(username)] = true;
	}
}

function clearAttempts(platform) {
	// Clear the array element with the index of the index in which the user's username is stored in the player array
	if(platform == 'twitch') {
		for(var e = 0; e < twitchRegistered.length; e++) {
			twitchAnswered[e] = false;
		}
	} else if(platform == 'discord') {
		for(var e = 0; e < discordRegistered.length; e++) {
			discordAnswered[e] = false;
		}
	}
}

// Pay user for correct answer
function payUser(platform, username, amount) {
	// Perform a query for the user's info from the correct platform database
	mysqlClient.query(`SELECT * FROM jeopardy_players_${platform} where name = '${username}'`, function (err, result, fields) {
		// Total the money that they should have after winning money
		var newMoney = amount + result[0]['money'];

		// Apply new money amount to the money array
		if(platform == 'twitch') {
			twitchMoney[twitchRegistered.indexOf(username)] = newMoney;
		} else if(platform == 'discord') {
			discordMoney[discordRegistered.indexOf(username)] = newMoney;
		}

		// Update database with new money amount
		var sql = `UPDATE jeopardy_players_${platform} SET money = '${newMoney}' WHERE name = '${username}'`;
		mysqlClient.query(sql, function (err, result) {});
	});
}

// Deduct user for wrong answer
function deductUser(platform, username, amount) {
	// Perform a query for the user's info from the correct platform database
	mysqlClient.query(`SELECT * FROM jeopardy_players_${platform} where name = '${username}'`, function (err, result, fields) {
		// Total the money that they should have after losing money
		var newMoney = result[0]['money'] - amount;

		// Apply new money amount to the money array
		if(platform == 'twitch') {
			twitchMoney[twitchRegistered.indexOf(username)] = newMoney;
		} else if(platform == 'discord') {
			discordMoney[discordRegistered.indexOf(username)] = newMoney;
		}

		// Update database with new money amount
		var sql = `UPDATE jeopardy_players_${platform} SET money = '${newMoney}' WHERE name = '${username}'`;
		mysqlClient.query(sql, function (err, result) {});
	});
}

// Register for Trivia
function register(platform, username) {
  	// Insert a new record into the platform database for the new user
	var sql = `INSERT INTO jeopardy_players_${platform} (name) VALUES ('${username}')`;
	mysqlClient.query(sql, function (err, result) {
		// Set array values for the user
		if(platform == 'twitch') {
			twitchRegistered[twitchRegistered.length] = username;
			twitchAnswered[twitchAnswered.length] = false;
			twitchMoney[twitchMoney.length] = 0;
		} else if(platform == 'discord') {
			discordRegistered[discordRegistered.length] = username;
			discordAnswered[discordAnswered.length] = false;
			discordMoney[discordMoney.length] = 0;
		}
		console.log(`User: ${username} has been registered!\n`);
	});
}

//Check if registered
function checkIfReg(platform, username) {
	// Check registered users array if the user is registered and return true or false
	if(platform == 'twitch') {
		return twitchRegistered.includes(username);
	} else if(platform == 'discord') {
		return discordRegistered.includes(username);
	}
}

// Starts the login chain.
function Login() {
	// Log into MYSQL
	mysqlLogin();

	// Define MYSQL Login Function
	function mysqlLogin() {
	    console.log("Connecting to the database...\n");

	    // Setup client with the defined variables above
	    mysqlClient = mysql.createConnection({

			host: host,
			user: mysqlUser,
			password: mysqlAuth,
			database: database
	    });

	    // Attempt to connect to the MYSQL database
	    mysqlClient.connect(function(error) {
			// Log a failed connection and quit
			if(error) {
				console.log("MYSQL Database Couldn't Login!\n\nTerminating Bot...");

				process.exit();
			}

			// Log a successful connection
			console.log("Connected to your MYSQL database!\n");

			// Log into the services as instructed above
			if(TwitchRun) {
				twitchLogin();
			} else if(DiscordRun) {
				discordLogin();
			} else {
				console.log("No services are set to run...\n\nTerminating Bot...");

				process.exit();
			}
	    });
  	}

	// Define Twitch Login Function
	function twitchLogin() {
		// Log the start of the connection
		console.log("Connecting to Twitch...\n");

		// Define configuration using the defined variables above
		const opts = {

			identity: {
				username: twitchBotName,
				password: twitchAuth
			},
			channels: channelsToWatch
		};

		// Create a client with the configuration
		twitchClient = new tmi.client(opts);

		// Register our event handlers
		twitchClient.on('connected', onConnectedHandler);
		twitchClient.on('message', onMessageTwitch);

		// Set Bot to stop attempting connection after 5 seconds
		var twitchTimeout = setTimeout(failedToConnect, 5000);

		// Connect to Twitch:
		twitchClient.connect().catch(failedToConnect);

		// Called every time the bot connects to Twitch chat
		function onConnectedHandler (addr, port) {
			// Stop bot from timing out
			clearTimeout(twitchTimeout);

			// Log a successful connection
			console.log(`Connected to Twitch @ ${addr}:${port}!\n`);

			// Start the Discord Login If Needed
			if(DiscordRun) {
				discordLogin();
			}
	    }

	    // Log a failed connection and quit
	    function failedToConnect () {
			console.log('Failed to connect to Twitch!\n\nTerminating Bot...');

			process.exit();
	    }
	}

	// Define Discord Login Function
	function discordLogin() {
		// Log the start of the connection
		console.log("Connecting to Discord...\n");

		// Create a Discord client and login
		discordClient = new Discord.Client();
		discordClient.login(discordAuth);

		// Register our event handlers
		discordClient.on('message', onMessageDiscord);

		// Run upon connecting to Discord Servers
		discordClient.on('ready', () => {
			// Log a successful connection
			console.log("Connected to Discord!\n");

			// Set a status for the bot
			discordClient.user.setActivity('Trivia - *help', { type: 'PLAYING' });
		});

		// Log an error
		discordClient.on('error', () => {
			console.log("Failed to connect to Discord!\n\nTerminating Bot...");
		});
	}
}

// Update channelsToWatch array and change sync mode if need be
function channelsLiveRun() {
	// A variable to track if Live statuses change or sync status
	var wereLive = channelsLive.includes(true);
	var wasSync = synchronousMode;

	// Call checkIfLive for each channel
	for(var j = 0; j < channelsToWatch.length; j++) {
		checkIfLive(channelsToWatch[j], j);
	}

	// Sync questions between Discord and Twitch
	syncQuestionStatus(wereLive, wasSync);
}

// Change sync status and questions if need be
function syncQuestionStatus(wereLive, wasSync) {
	// Check if any are live now
	var nowLive = channelsLive.includes(true);

	// Check if any channel is online
	if(nowLive) {
		// Check if Discord is a running service
		if(DiscordRun) {
			// Set Sync mode autoSyncMode synchronousMode
			synchronousMode = autoSyncMode;

			// If the sync has changed
			if(wasSync != synchronousMode) {
				syncQuestions(); // Need to sync non sync'd discord questions with twitch
				// If weren't live but now is
			} else if(nowLive != werelive) {
				desyncQuestionsToTwitch(); // Need to create twitch non sync'd questions
			}
		} else {
			// If weren't live but now is
			if(nowLive != wereLive) {
				startQuestions(); // Need to start questions completely
			}
		}
	} else {
		// Check if Discord is a running service
		if(DiscordRun) {
			// Set Sync mode synchronousMode
			synchronousMode = false;

			// If the sync has changed
			if(wasSync != synchronousMode) {
				desyncQuestionsToDiscord(); // Need to desync questions from sync'd to just discord
			}
		} else {
			// If were live but not anymore
			if(nowLive != wereLive) {
				endQuestions(); // Need to stop questions completely
			}
		}
	}
}

// Initial Startup Question Sequence
function initQuestions() {
	// Check if any are live now
	var nowLive = channelsLive.includes(true);

	// If Twitch is set to run and the channel is live
	if(TwitchRun && nowLive) {
		// If Discord is set to run
		if(DiscordRun) {
			// If bot is set to sync mode
			if(synchronousMode) {
				makeQuestion('sync');
				setTimer('both');
			} else {
				makeQuestion('async_both');
				setTimer('both');
			}
		} else {
			makeQuestion('async_twitch');
			setTimer('twitch');
		}
	} else if(DiscordRun) {
		makeQuestion('async_discord');
		setTimer('discord');
	}
}

// Set the timer for the questions intervals
function setTimer(type) {
	// Figure out time to next interval
	var d = new Date();
	var n = d.getHours();
	var m = d.getMinutes();
	var timeToSkip = null;
	var minutesToNext = null;

	/*
		Just gonna do a comment block because this can be really confusing.
		Pretty much if type == both then set a timer that is for both Twitch and Discord.
		Otherwise create a timer seperate from one another.

		The mess you see here is figuring out when the next time within an hour your selected interval will occur.

		For instance, an interval of 5 minutes should occur when the time has minutes ending in a 0 or 5.

		Or as my math has it, 60 minutes minus the current minutes, modulus (divide but output is the remainder) the interval.

		Then format the time in string form with proper 0's.
	*/
	if(type == 'both') {
		timeToSkip = (60 - m) % timeBetweenQuestions;
		minutesToNext = m + timeToSkip;

		if(timeToSkip <= 1) {
			timeToSkip = timeToSkip + timeBetweenQuestions;
			minutesToNext = minutesToNext + timeBetweenQuestions;

			if(timeToSkip + m == 60) {
				var nextHour = n + 1;

				if(nextHour == 24) {
					nextQuestionTime = "00" + `:00 ${timezone}`;
				} else {
					nextQuestionTime = nextHour + ":00";
				}
			} else if(n < 10) {
				if(timeToSkip + m < 10) {
					nextQuestionTime = `0${n}:0${minutesToNext}`;
				} else {
					nextQuestionTime = `0${n}:${minutesToNext}`;
				}
			} else {
				if(timeToSkip + m < 10) {
					nextQuestionTime = `${n}:0${minutesToNext}`;
				} else {
					nextQuestionTime = `${n}:${minutesToNext}`;
				}
			}
		} else if(timeToSkip + m == 60) {
			var nextHour = n + 1;

			if(nextHour == 24) {
				nextQuestionTime = "00" + `:00 ${timezone}`;
			} else {
				nextQuestionTime = nextHour + ":00";
			}
		} else {
			if(timeToSkip + m == 60) {
				var nextHour = n + 1;

				if(nextHour == 24) {
					nextQuestionTime = "00" + `:00 ${timezone}`;
				} else {
					nextQuestionTime = nextHour + ":00";
				}
			} else if(n < 10) {
				if(timeToSkip + m < 10) {
					nextQuestionTime = `0${n}:0${minutesToNext}`;
				} else {
					nextQuestionTime = `0${n}:${minutesToNext}`;
				}
			} else {
				if(timeToSkip + m < 10) {
					nextQuestionTime = `${n}:0${minutesToNext}`;
				} else {
					nextQuestionTime = `${n}:${minutesToNext}`;
				}
			}
		}
		setTimeout(setI, timeToSkip * minute, type);
	} else if(type == 'twitch') {
		timeToSkip = (60 - m) % timeBetweenQuestionsTwitch;
		minutesToNext = m + timeToSkip;

		if(timeToSkip <= 1) {
			timeToSkip = timeToSkip + timeBetweenQuestionsTwitch;
			minutesToNext = minutesToNext + timeBetweenQuestionsTwitch;

			if(timeToSkip + m == 60) {
				var nextHour = n + 1;

				if(nextHour == 24) {
					nextQuestionTwitch = "00" + `:00 ${timezone}`;
				} else {
					nextQuestionTwitch = nextHour + ":00";
				}
			} else if(n < 10) {
				if(timeToSkip + m < 10) {
					nextQuestionTwitch = `0${n}:0${minutesToNext}`;
				} else {
					nextQuestionTwitch = `0${n}:${minutesToNext}`;
				}
			} else {
				if(timeToSkip + m < 10) {
					nextQuestionTwitch = `${n}:0${minutesToNext}`;
				} else {
					nextQuestionTwitch = `${n}:${minutesToNext}`;
				}
			}
		} else if(timeToSkip + m == 60) {
			var nextHour = n + 1;

			if(nextHour == 24) {
				nextQuestionTwitch = "00" + `:00 ${timezone}`;
			} else {
				nextQuestionTwitch = nextHour + ":00";
			}
		} else {
			if(timeToSkip + m == 60) {
				var nextHour = n + 1;

				if(nextHour == 24) {
					nextQuestionTwitch = "00" + `:00 ${timezone}`;
				} else {
					nextQuestionTwitch = nextHour + ":00";
				}
			} else if(n < 10) {
				if(timeToSkip + m < 10) {
					nextQuestionTwitch = `0${n}:0${minutesToNext}`;
				} else {
					nextQuestionTwitch = `0${n}:${minutesToNext}`;
				}
			} else {
				if(timeToSkip + m < 10) {
					nextQuestionTwitch = `${n}:0${minutesToNext}`;
				} else {
					nextQuestionTwitch = `${n}:${minutesToNext}`;
				}
			}
		}
		setTimeout(setI, timeToSkip * minute, type);
	} else if(type == 'discord') {
		timeToSkip = (60 - m) % timeBetweenQuestionsDiscord;
		minutesToNext = m + timeToSkip;

		if(timeToSkip <= 1) {
			timeToSkip = timeToSkip + timeBetweenQuestionsDiscord;
			minutesToNext = minutesToNext + timeBetweenQuestionsDiscord;

			if(timeToSkip + m == 60) {
				var nextHour = n + 1;

				if(nextHour == 24) {
					nextQuestionDiscord = "00" + `:00 ${timezone}`;
				} else {
					nextQuestionDiscord = nextHour + ":00";
				}
			} else if(n < 10) {
				if(timeToSkip + m < 10) {
					nextQuestionDiscord = `0${n}:0${minutesToNext}`;
				} else {
					nextQuestionDiscord = `0${n}:${minutesToNext}`;
				}
			} else {
				if(timeToSkip + m < 10) {
					nextQuestionDiscord = `${n}:0${minutesToNext}`;
				} else {
					nextQuestionDiscord = `${n}:${minutesToNext}`;
				}
			}
		} else if(timeToSkip + m == 60) {
			var nextHour = n + 1;

			if(nextHour == 24) {
				nextQuestionDiscord = "00" + `:00 ${timezone}`;
			} else {
				nextQuestionDiscord = nextHour + ":00";
			}
		} else {
			if(timeToSkip + m == 60) {
				var nextHour = n + 1;

				if(nextHour == 24) {
					nextQuestionDiscord = "00" + `:00 ${timezone}`;
				} else {
					nextQuestionDiscord = nextHour + ":00";
				}
			} else if(n < 10) {
				if(timeToSkip + m < 10) {
					nextQuestionDiscord = `0${n}:0${minutesToNext}`;
				} else {
					nextQuestionDiscord = `0${n}:${minutesToNext}`;
				}
			} else {
				if(timeToSkip + m < 10) {
					nextQuestionDiscord = `${n}:0${minutesToNext}`;
				} else {
					nextQuestionDiscord = `${n}:${minutesToNext}`;
				}
			}
		}
		setTimeout(setI, timeToSkip * minute, type);
	}
}

// Set the timer for the questions intervals
function setI(type) {
	// Run the questions in the correct services and get the bot ready to run another question in the set interval
	if(type == 'both') {
		runQuestion('sync');
		intervalRunner = setInterval(runQuestion, timeBetweenQuestions * minute, 'sync');
	} else if(type == 'twitch') {
		runQuestion('async_twitch');
		intervalRunnerT = setInterval(runQuestion, timeBetweenQuestionsTwitch * minute, 'async_twitch');
	} else if(type == 'discord') {
		runQuestion('async_discord');
		intervalRunnerD = setInterval(runQuestion, timeBetweenQuestionsDiscord * minute, 'async_discord');
	}
}

// Create question / questions
function makeQuestion(type) {
	// Create the question for the correct service
	if(type == 'sync') {
		// Erase all current questions
		eraseAll();

		questionUsed(type);
		setTimeout(fetchQuestion, 8 * second, type); // Set a timeout for five seconds to wait until used has a value
	} else if(type == 'async_both') {
		// Erase all current questions
		eraseAll();

		questionUsed('async_twitch');
		questionUsed('async_discord');
		setTimeout(fetchQuestion, 8 * second, 'async_twitch'); // Set a timeout for five seconds to wait until used has a value
		setTimeout(fetchQuestion, 8 * second, 'async_discord'); // Set a timeout for five seconds to wait until used has a value
	} else if(type == 'async_twitch') {
		// Erase all current questions
		eraseTwitch();
		eraseSync();

		questionUsed(type);
		setTimeout(fetchQuestion, 8 * second, type); // Set a timeout for five seconds to wait until used has a value
	} else if(type == 'async_discord') {
		// Erase all current questions except Twitch
		eraseDiscord();
		eraseSync();

		questionUsed(type);
		setTimeout(fetchQuestion, 5 * second, type); // Set a timeout for five seconds to wait until used has a value
	}
}

// Grab lowest amount of used for questions
function questionUsed(type) {
	if(type == 'sync') {
		// Grab the lowest number used
		mysqlClient.query("SELECT * FROM jeopardy ORDER BY used_both ASC", function (err, result, fields) {
			Sused = result[0]['used_both'];
		});
	} else if(type == 'async_twitch') {
		// Grab the lowest number used
		mysqlClient.query("SELECT * FROM jeopardy ORDER BY used_twitch ASC", function (err, result, fields) {
			Tused = result[0]['used_twitch'];
		});
	} else if(type == 'async_discord') {
		// Grab the lowest number used
		mysqlClient.query("SELECT * FROM jeopardy ORDER BY used_discord ASC", function (err, result, fields) {
			Dused = result[0]['used_discord'];
		});
	}
}

// Fetch the question based on platform and used count
function fetchQuestion(type) {
	if(type == 'sync') {
		// Grab the lowest number used
		mysqlClient.query(`SELECT * FROM jeopardy where used_both = ${Sused}`, function (err, result, fields) {
			var randomN = random(0, result.length - 1);

			if(typeof result[randomN] !== 'undefined') {
				var questionSelected = result[randomN];
				var lowest1 = Sused + 1;

				// Update the question's field to say it was used
				var sql = "UPDATE jeopardy SET used_both = " + lowest1 + " WHERE id = " + questionSelected['id'];

				// Update the count of the question selected
				mysqlClient.query(sql, function (err, result) {});

				// Set question parameters
				questionid = questionSelected['id'];
				questionDate = questionSelected['air_date'];
				category = questionSelected['category'];
				question = questionSelected['question'];
				answer = questionSelected['answer'].toLowerCase();
				var firstValue = questionSelected['value'];
				Sused = lowest1;

				if(firstValue == 'None') {
					value = 3000;
				} else {
					value = parseInt(questionSelected['value'].substring(1).replaceAll(',', ''));
				}
			} else {
				console.log(result);
				console.log(Sused);
			} 
		});
	} else if(type == 'async_twitch') {
		// Grab the lowest number used
		mysqlClient.query(`SELECT * FROM jeopardy where used_twitch = ${Tused}`, function (err, result, fields) {

			var randomN = random(0, result.length - 1);

			if(typeof result[randomN] !== 'undefined') {
				var questionSelected = result[randomN];
				var lowest1 = Tused + 1;

				// Update the question's field to say it was used
				var sql = "UPDATE jeopardy SET used_twitch = " + lowest1 + " WHERE id = " + questionSelected['id'];

				// Update the count of the question selected
				mysqlClient.query(sql, function (err, result) {});

				// Set question parameters
				Tquestionid = questionSelected['id'];
				TquestionDate = questionSelected['air_date'];
				Tcategory = questionSelected['category'];
				Tquestion = questionSelected['question'];
				Tanswer = questionSelected['answer'].toLowerCase();
				var firstValue = questionSelected['value'];
				Tused = lowest1;

				if(firstValue == 'None') {
					Tvalue = 3000;
				} else {
					Tvalue = parseInt(questionSelected['value'].substring(1).replaceAll(',', ''));
				}
			} else {
			console.log(result);
			console.log(Tused);
			}
		});
	} else if(type == 'async_discord') {
		// Grab the lowest number used
		mysqlClient.query(`SELECT * FROM jeopardy where used_discord = ${Dused}`, function (err, result, fields) {
			var randomN = random(0, result.length - 1);

			if(typeof result[randomN] !== 'undefined') {
				var questionSelected = result[randomN];
				var lowest1 = Dused + 1;

				// Update the question's field to say it was used
				var sql = "UPDATE jeopardy SET used_discord = " + lowest1 + " WHERE id = " + questionSelected['id'];

				// Update the count of the question selected
				mysqlClient.query(sql, function (err, result) {});

				// Set question parameters
				Dquestionid = questionSelected['id'];
				DquestionDate = questionSelected['air_date'];
				Dcategory = questionSelected['category'];
				Dquestion = questionSelected['question'];
				Danswer = questionSelected['answer'].toLowerCase();
				var firstValue = questionSelected['value'];
				Dused = lowest1;

				if(firstValue == 'None') {
					Dvalue = 3000;
				} else {
					Dvalue = parseInt(questionSelected['value'].substring(1).replaceAll(',', ''));
				}
			} else {
			console.log(result);
			console.log(Dused);
			}
		});
	}
}

// Erase all question related variables
function eraseAll() {
	questionid = null;
	questionDate = null;
	category = null;
	question = null;
	answer = null;
	value = null;
	answered = false;
	answeredTwitch = false;
	answeredDiscord = false;
	questiontime = false;
	questiontimeTwitch = false;
	questiontimeDiscord = false;
	Sused = null;

	Tquestionid = null;
	TquestionDate = null;
	Tcategory = null;
	Tquestion = null;
	Tanswer = null;
	Tvalue = null;
	Tanswered = false;
	TansweredTwitch = false;
	TansweredDiscord = false;
	Tquestiontime = false;
	Tused = null;

	Dquestionid = null;
	DquestionDate = null;
	Dcategory = null;
	Dquestion = null;
	Danswer = null;
	Dvalue = null;
	Danswered = false;
	DansweredTwitch = false;
	DansweredDiscord = false;
	Dquestiontime = false;
	Dused = null;

	clearAttempts('twitch');
	clearAttempts('discord');
}

// Erase sync questions
function eraseSync() {
	questionid = null;
	questionDate = null;
	category = null;
	question = null;
	answer = null;
	value = null;
	answered = false;
	answeredTwitch = false;
	answeredDiscord = false;
	questiontime = false;
	questiontimeTwitch = false;
	questiontimeDiscord = false;
	Sused = null;

	clearAttempts('twitch');
	clearAttempts('discord');
}

// Erase Twitch questions
function eraseTwitch() {
	Tquestionid = null;
	TquestionDate = null;
	Tcategory = null;
	Tquestion = null;
	Tanswer = null;
	Tvalue = null;
	Tanswered = false;
	TansweredTwitch = false;
	TansweredDiscord = false;
	Tquestiontime = false;
	Tused = null;

	clearAttempts('twitch');
}

// Erase Discord questions
function eraseDiscord() {
	Dquestionid = null;
	DquestionDate = null;
	Dcategory = null;
	Dquestion = null;
	Danswer = null;
	Dvalue = null;
	Danswered = false;
	DansweredTwitch = false;
	DansweredDiscord = false;
	Dquestiontime = false;
	Dused = null;

	clearAttempts('discord');
}

// Startup the question sequence - Twitch Only
function startQuestions() {
	makeQuestion('async_twitch');

	intervalRunnerT = setInterval(runQuestion, timeBetweenQuestionsTwitch * minute, 'async_twitch');
}

// End the question sequence
function endQuestions() {
	// Get the update number
	lowest1 = Tused - 1;

	// Update the question's field to say it was used
	var sql = "UPDATE jeopardy SET used_twitch = " + lowest1 + " WHERE id = " + Tquestionid;

	// Erase all variables
	eraseAll();

	// Clear the interval of the question output function
	clearInterval(intervalRunnerT);
}

// Synchronize the question sequence
function syncQuestions() {
	// Get the update number
	lowest1 = Dused - 1;

	// Update the question's field to say it was used
	var sql = "UPDATE jeopardy SET used_discord = " + lowest1 + " WHERE id = " + Dquestionid;

	// Create a question for both Twitch and Discord
	makeQuestion('sync');

	// Set a timer for the question to be outputted
	setTimer('both');
}

// Desynchronize the question sequence to just Discord
function desyncQuestionsToDiscord() {
	// Get the update number
	lowest1 = Sused - 1;

	// Update the question's field to say it was used
	var sql = "UPDATE jeopardy SET used_both = " + lowest1 + " WHERE id = " + questionid;

	// Create a question for Twitch
	makeQuestion('async_twitch');

	// Set a timer for both
	setTimer('both');
}

// Desynchronize the question sequence to both Discord and Twitch
function desyncQuestionsToTwitch() {
	// Create a question for Twitch
	makeQuestion('async_twitch');

	// Create a timer for both
	setTimer('both');
}

// Answer Checker
function checkAnswer(actualAnswer, attemptedAnswer) {
	// Variables local to the function
	var answers = null;
	var similarity = null;
	var highest = null;

	/*
		Another block comment because this may be confusing.

		Some questions include multiple answers seperated by () or /, take these into account and check if user answer matches any of these options.

		The answers are "compared" using the stringSimularity library. This library provides us a rough percentage on how similar the two strings are.
		We can use this percentage to decicde just how "right" the user was. If the user was really close to getting the answer and maybe missed a
		letter or two or maybe forgot some small part of the answer, then we can forgive that and still provide them a win.
	*/
	if(actualAnswer.includes('(')) {
		answers = actualAnswer.split('(');

		for(var a = 0; a < answers.length; a++) {
			similarity = stringSimilarity.compareTwoStrings(answers[a].replaceAll(')', '').trim(), attemptedAnswer);

			if(similarity > highest) {
				highest = similarity;
			}
		}

		if(highest  >= answerSimilarityPercent) {
			return true;
		} else {
			return false;
		}
	} else if(actualAnswer.includes('/')) {
		answers = actualAnswer.split('/');

		for(var b = 0; b < answers.length; b++) {
			similarity = stringSimilarity.compareTwoStrings(answers[b].trim(), attemptedAnswer);

			if(similarity > highest) {
				highest = similarity;
			}
		}

		if(highest  >= answerSimilarityPercent) {
			return true;
		} else {
			return false;
		}
	} else{
		var similarity = stringSimilarity.compareTwoStrings(actualAnswer.replaceAll(',', ''), attemptedAnswer.replaceAll(',', ''));

		if(similarity  >= answerSimilarityPercent) {
			return true;
		} else {
			return false;
		}
	}
}

// Money Checker
function checkMoney(platform, username) {
	// Check the money array based on platform and username, return money value
	if(platform == 'twitch') {
		return twitchMoney[twitchRegistered.indexOf(username)];
	} else if(platform == 'discord') {
		return discordMoney[discordRegistered.indexOf(username)];
	}

	return money;
}

// Run the question
function runQuestion(type) {
	// Based on platform and sync, output the question to the appropriate services
	if(type == 'sync') {
		if(syncSharedMode) {
			answered = false;
			questiontime = true;
			answersUpRunner = setTimeout(answersUp, second * timeToAnswer, type);
		} else {
			answeredTwitch = false;
			answeredDiscord = false;
			questiontimeTwitch = true;
			questiontimeDiscord = true;
			answersUpRunnerT = setTimeout(answersUp, second * timeToAnswer, type);
		}

		// Run through and run the question on all live Twitch Channels
		for(var t = 0; t < channelsToWatch.length; t++) {
			if(channelsLive[t]) {
				twitchClient.say(`#${channelsToWatch[t]}`, `Question Time! Date: ${questionDate}; Category: ${category}; Question for $${value}: ${question}! You have ${timeToAnswer} seconds to answer!`);
			}
		}
	} else if(type == 'async_twitch') {
		Tanswered = false;
		Tquestiontime = true;

		// Run through and run the question on all live Twitch Channels
		for(var t = 0; t < channelsToWatch.length; t++) {
			if(channelsLive[t]) {
				twitchClient.say(`#${channelsToWatch[t]}`, `Question Time! Date: ${TquestionDate}; Category: ${Tcategory}; Question for $${Tvalue}: ${Tquestion}! You have ${timeToAnswerTwitch} seconds to answer!`);
			}
		}

		answersUpRunnerT = setTimeout(answersUp, second * timeToAnswerTwitch, type);
	} else if(type == 'async_discord') {
		Danswered = false;
		Dquestiontime = true;

		discordClient.channels.cache.get(discordBotChannel).send(`Question Time! Date: ${DquestionDate}; Category: ${Dcategory}; Question for $${Dvalue}: ${Dquestion}! You have ${timeToAnswerDiscord} seconds to answer!`);

		answersUpRunnerD = setTimeout(answersUp, second * timeToAnswerDiscord, type);
	}
}

// Answer Time Up
function answersUp(type) {
	// Output the correct answer to the correct services and begin the process to create a new question
	if(type == 'sync') {
		// Run through and run the answer on all live Twitch Channels
		for(var t = 0; t < channelsToWatch.length; t++) {
			if(channelsLive[t]) {
				twitchClient.say(`#${channelsToWatch[t]}`, `Correct Answer: ${answer}!`);
			}
		}

		makeQuestion(type);
	} else if(type == 'async_twitch') {
		// Run through and run the answer on all live Twitch Channels
		for(var t = 0; t < channelsToWatch.length; t++) {
			if(channelsLive[t]) {
				twitchClient.say(`#${channelsToWatch[t]}`, `Correct Answer: ${Tanswer}!`);
			}
		}

		makeQuestion(type);
	} else if(type == 'async_discord') {
		discordClient.channels.cache.get(discordBotChannel).send(`Correct Answer: ${Danswer}!`);

		makeQuestion(type);
	}
}

// Check if the channel is live currently
function checkIfLive(channel, index) {
	// Client ID that will be received from the first call
	var retrievedClient_id = null;

	// Request options for the first call to validate your Twitch Bot
	var options = {
		'method': 'GET',
		'url': 'https://id.twitch.tv/oauth2/validate',
		'headers': {
			'client-id': twitchClientID,
			'Authorization': 'Bearer ' + twitchAuth
		}
	};

	request(options, function (error, response) {
		// If error, set live status to false to avoid issues and alert the console.
		if (error) {
			console.log(`Failed to check live status of ${channel}, status set to not live!`);
			channelsLive[index] = false;
		}

		// Parse the response body and grab the client id
		body = JSON.parse(response.body);
		retrievedClient_id = body.client_id;

		// Request options for the second call to check the live status of the channel
		var options = {
			'method': 'GET',
			'url': `https://api.twitch.tv/helix/streams/?user_login=${channel}`,
			'headers': {
				'client-id': retrievedClient_id,
				'Authorization': `Bearer ${twitchAuth}`
			}
		};

		request(options, function (error, response) {
			// If error, set live status to false to avoid issues and alert the console.
			if (error) {
				console.log(`Failed to check live status of ${channel}, status set to not live!`);
				channelsLive[index] = false;
			}

			// Parse the response body
			body2 = JSON.parse(response.body);

			// If data has more than zero items, channel is live
			if(typeof body2.data !== 'undefined') {
				if(body2.data.length != 0) {
					channelsLive[index] = true;
				} else {
					channelsLive[index] = false;
				}
			} else {
				channelsLive[index] = false;
			}
		});
	});
}

// Generate a random number
function random(min, max) {
	return Math.floor(Math.random() * (max - min) ) + min;
}